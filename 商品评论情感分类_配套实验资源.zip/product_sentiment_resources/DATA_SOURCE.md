# 数据位置与来源

本资源包已附用户上传数据包中的CSV，文件位于：

data/raw/online_shopping_10_cats.csv

## 发布来源

发布仓库：SophonPlus/ChineseNlpCorpus

数据说明：
https://github.com/SophonPlus/ChineseNlpCorpus/blob/master/datasets/online_shopping_10_cats/intro.ipynb

原发布压缩包：
https://raw.githubusercontent.com/SophonPlus/ChineseNlpCorpus/master/datasets/online_shopping_10_cats/online_shopping_10_cats.zip

如需重新获取，下载压缩包后解压CSV到上面的路径。发布说明将具体电商平台、原作者和来源记为不详；第三方数据的权利与使用条件以其来源说明为准。

## 字段与实验范围

cat表示品类，review表示评论文本，label中0为负向、1为正向。完整CSV有62,774条记录，本实验代码只取“手机”，共2,323条，负向1,158条、正向1,165条。

程序整理空白和字符格式，处理标签冲突与完全重复，再用随机种子42划分。训练、开发、测试集分别为1,626、348、349条。

## 文件核对

CSV大小：11,299,695字节。

SHA256：
f6c5b724122d8547b700ac4524898eb7e28abbee63f798e95a8faa408829afdb

用户上传的CSV与本轮参考运行所用CSV哈希一致。评价采用语料自带标签。
