# 商品评论情感分类实验复现资源

本资源包含数据、Notebook、Python代码和本轮参考结果。数据已经解压放在data/raw/online_shopping_10_cats.csv，完整解压本资源包后即可读取。

## 在Windows中运行

1. 将整个ZIP解压到一个文件夹，进入其中含README.md和experiment.py的目录。
2. 在这个目录打开PowerShell，使用Python 3.12执行以下命令。

```powershell
py -3.12 -m venv .venv
.\.venv\Scripts\python.exe -m pip install -r requirements.txt
.\.venv\Scripts\python.exe -m jupyterlab
```

3. 在Jupyter中打开“商品评论情感分类实验.ipynb”，按代码顺序运行。结果写入my_run/。

使用Windows时采用上面这组命令即可。WSL/Linux的对应命令放在本文最后，供其他系统复现。

## 数据位置与来源

已附CSV：data/raw/online_shopping_10_cats.csv。

数据来自SophonPlus/ChineseNlpCorpus发布的online_shopping_10_cats语料。本轮只筛选“手机”子集，包含2,323条评论。

数据说明：
https://github.com/SophonPlus/ChineseNlpCorpus/blob/master/datasets/online_shopping_10_cats/intro.ipynb

原发布数据包：
https://raw.githubusercontent.com/SophonPlus/ChineseNlpCorpus/master/datasets/online_shopping_10_cats/online_shopping_10_cats.zip

字段、样本量与文件哈希见DATA_SOURCE.md。需要重新获取数据时，下载原发布数据包并解压到同一路径。

## 脚本入口

Windows下也可以直接运行完整脚本：

```powershell
.\.venv\Scripts\python.exe experiment.py --data data/raw/online_shopping_10_cats.csv --out my_run
```

增加--export-text会生成带评论的分析表，已有表格会保留。

## 资源文件

- experiment.py：清理、划分、训练和导出的公共函数。
- 商品评论情感分类实验.ipynb：无输出的复现入口。
- data/raw/online_shopping_10_cats.csv：已附原始数据。
- figures/：手册中的六幅图。
- reference_run/：参考指标、划分、预测行号、分歧分析及复现检查记录。
- templates/：评论分析、研究笔记和复现记录表。
- my_run/：执行后生成的结果目录。

Mate对应文献与方案梳理、已有结果的提纲整理，具体计算及指标由Python输出。

## 复现检查记录

reference_run/复现检查记录.md说明本次检查过程，submission_check.json保存环境与检查结果，executed_notebook.ipynb保留逐单元格运行输出。

## 对照结果

训练/开发/测试集分别为1,626/348/349条。测试混淆矩阵为[[165,9],[11,164]]，准确率94.27%，宏平均F1为0.9427。

## WSL或Linux的对应命令

在资源根目录执行：

```bash
python3 -m venv .venv
.venv/bin/python -m pip install -r requirements.txt
.venv/bin/python -m jupyterlab
```
