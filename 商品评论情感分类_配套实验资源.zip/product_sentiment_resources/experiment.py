"""商品评论分类实验基线。数据获取方法见DATA_SOURCE.md。"""
from __future__ import annotations
import csv
import hashlib
import json
import platform
import re
import sys
import time
import unicodedata
from datetime import datetime, timezone, timedelta
from importlib.metadata import version
from pathlib import Path

import numpy as np
import pandas as pd
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import accuracy_score, confusion_matrix, f1_score
from sklearn.model_selection import train_test_split
from sklearn.pipeline import Pipeline

SEED = 42
GROUPS = ['未命中提示词', '仅否定提示词', '仅转折提示词', '两类提示词均有']
NEGATION = re.compile(r'不|没|无|未|别|非')
CONTRAST = re.compile(r'但是|不过|可是|然而|虽然|尽管|只是|但|却')

def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()

def normalize(text):
    return re.sub(r'\s+', ' ', unicodedata.normalize('NFKC', str(text))).strip()

def keyword_group(text):
    """先按提示词筛选，具体表达再结合原句理解。"""
    a, b = bool(NEGATION.search(text)), bool(CONTRAST.search(text))
    return GROUPS[int(a) + 2 * int(b)]

def prepare(csv_path, category='手机'):
    raw = pd.read_csv(csv_path)
    if not {'cat', 'label', 'review'}.issubset(raw.columns):
        raise ValueError('输入 CSV 必须包含 cat、label、review 三列')
    df = raw.loc[raw['cat'].eq(category)].copy()
    df['row_id'] = [f'raw_{i}' for i in df.index]
    n_category = len(df)
    df = df.dropna(subset=['review', 'label'])
    df['review'] = df['review'].map(normalize)
    df = df[df['review'].str.len().gt(0)]
    df['label'] = pd.to_numeric(df['label'], errors='raise').astype(int)
    if set(df['label']) != {0, 1}:
        raise ValueError('分类需要 0、1 两类参考标签')
    before_conflict = len(df)
    conflicting = df.groupby('review')['label'].nunique()
    conflicting = set(conflicting[conflicting.gt(1)].index)
    df = df[~df['review'].isin(conflicting)].copy()
    conflict_rows = before_conflict - len(df)
    before_duplicate = len(df)
    df = df.drop_duplicates(subset='review').copy()
    df['chars'] = df['review'].str.len()
    df['keyword_group'] = df['review'].map(keyword_group)
    # 完全重复文本已合并，再划分数据；近似改写仍需另行检查。
    train, remaining = train_test_split(df, test_size=0.30, stratify=df['label'], random_state=SEED)
    dev, test = train_test_split(remaining, test_size=0.50, stratify=remaining['label'], random_state=SEED)
    assert not (set(train.review) & set(dev.review) or set(train.review) & set(test.review) or set(dev.review) & set(test.review))
    audit = {
        'raw_rows_all_categories': len(raw), 'category': category, 'category_raw_rows': n_category,
        'missing_or_empty_removed': n_category - before_conflict,
        'conflicting_label_rows_removed': conflict_rows,
        'duplicate_rows_removed': before_duplicate - len(df),
        'clean_rows': len(df), 'positive_rows': int(df.label.sum()), 'negative_rows': int((df.label == 0).sum()),
        'split_sizes': {'train': len(train), 'dev': len(dev), 'test': len(test)},
        'near_duplicate_audit': 'not_completed',
        'label_provenance': 'original_reference_labels_not_independently_adjudicated',
        'dataset_permission': 'original_source_and_redistribution_terms_pending_confirmation',
    }
    return raw, df, train, dev, test, audit

def build_model():
    return Pipeline([
        ('tfidf', TfidfVectorizer(analyzer='char', ngram_range=(1, 3), min_df=2,
                                max_features=20000, sublinear_tf=True)),
        ('clf', LogisticRegression(C=1.0, max_iter=1000, random_state=SEED)),
    ])

def score_frame(frame, predictions):
    out = frame.copy()
    out['prediction'] = np.asarray(predictions, dtype=int)
    out['correct'] = out.label.eq(out.prediction)
    return out

def metric_record(frame, name):
    n = len(frame)
    if not n:
        return {'group': name, 'n': 0, 'correct': 0, 'accuracy': None, 'macro_f1': None,
                'positive_fraction': None, 'median_chars': None}
    return {'group': name, 'n': n, 'correct': int(frame.correct.sum()),
            'accuracy': float(accuracy_score(frame.label, frame.prediction)),
            'macro_f1': float(f1_score(frame.label, frame.prediction, labels=[0, 1], average='macro', zero_division=0)),
            'positive_fraction': float(frame.label.mean()), 'median_chars': float(frame.chars.median())}

def write_json(path, obj):
    Path(path).write_text(json.dumps(obj, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')

def run(csv_path, outdir, category='手机', export_text=False):
    start = time.perf_counter()
    out = Path(outdir); out.mkdir(parents=True, exist_ok=True)
    raw, df, train, dev, test, audit = prepare(csv_path, category)
    model = build_model()
    model.fit(train.review, train.label)
    # 本轮不搜索超参数。C=1.0 等设置在读取测试结果之前固定。
    dev_result = score_frame(dev, model.predict(dev.review))
    test_result = score_frame(test, model.predict(test.review))
    groups = [metric_record(test_result, '全部测试样本')]
    groups += [metric_record(test_result[test_result.keyword_group.eq(g)], g) for g in GROUPS]
    records = {'dev': metric_record(dev_result, '开发集'), 'test': groups[0],
               'keyword_candidates': groups,
               'confusion_matrix_label_order': [0, 1],
               'test_confusion_matrix': confusion_matrix(test_result.label, test_result.prediction, labels=[0, 1]).tolist(),
               'reference_basis': '语料自带标签',
               'group_basis': '按否定与转折提示词匹配分组'}
    pd.DataFrame(groups).to_csv(out/'group_metrics.csv', index=False, encoding='utf-8-sig')
    split_rows = []
    for name, part in [('train', train), ('dev', dev), ('test', test)]:
        split_rows.extend({'row_id': r.row_id, 'split': name, 'label': r.label} for r in part.itertuples())
    pd.DataFrame(split_rows).to_csv(out/'split_manifest.csv', index=False, encoding='utf-8-sig')
    public_columns = ['row_id', 'label', 'prediction', 'correct', 'keyword_group', 'chars']
    test_result[public_columns].to_csv(out/'predictions_without_text.csv', index=False, encoding='utf-8-sig')
    if export_text:
        # 仅在使用者本地生成，用于人工复核。分享前按数据许可处理。
        review = test_result[['row_id','review','keyword_group']].copy()
        for col in ['human_reference_label','confirmed_negation','confirmed_contrast','reviewer','reason']:
            review[col] = ''
        review_path = out/'human_review_local.csv'
        if not review_path.exists():
            review.to_csv(review_path, index=False, encoding='utf-8-sig')
    write_json(out/'data_audit.json', audit)
    write_json(out/'metrics.json', records)
    manifest = {'run_time': datetime.now(timezone(timedelta(hours=8))).isoformat(timespec='seconds'),
                'python': sys.version.split()[0], 'platform': platform.platform(),
                'packages': {p: version(p) for p in ['numpy','scipy','pandas','scikit-learn','matplotlib']},
                'data_sha256': digest(csv_path), 'seed': SEED, 'elapsed_seconds': time.perf_counter()-start,
                'model': 'character TF-IDF 1-3 grams plus logistic regression',
                'parameters': {'min_df':2,'max_features':20000,'C':1.0,'max_iter':1000},
                'hyperparameter_search': False, 'test_used_to_fit': False,
                'mate_used': False, 'external_api_called': False,
                'human_review_completed': False}
    write_json(out/'run_manifest.json', manifest)
    return {'raw': raw, 'clean': df, 'train': train, 'dev': dev, 'test': test_result,
            'model': model, 'audit': audit, 'metrics': records, 'manifest': manifest}

if __name__ == '__main__':
    import argparse
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--data', required=True, type=Path)
    parser.add_argument('--out', default='my_run', type=Path)
    parser.add_argument('--category', default='手机')
    parser.add_argument('--export-text', action='store_true', help='在输出目录生成带评论的分析表')
    args = parser.parse_args()
    result = run(args.data, args.out, args.category, args.export_text)
    print(json.dumps({'audit':result['audit'], 'metrics':result['metrics']}, ensure_ascii=False, indent=2))
